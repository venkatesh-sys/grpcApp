package com.trp.order.ordermangmnt;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OrderMangmntApplication {

	public static void main(String[] args) {
		SpringApplication.run(OrderMangmntApplication.class, args);
	}

}
