package com.trp.order.ordermangmnt.controller;

import com.trp.order.Order;
import com.trp.order.ordermangmnt.model.OrderStatus;
import com.trp.order.ordermangmnt.service.OrderService;
import io.grpc.stub.StreamObserver;
import org.lognet.springboot.grpc.GRpcService;
import com.trp.order.ordermangmnt.grpcstubs.orderManagementGrpc.orderManagementImplBase;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.Date;

@GRpcService
public class GrpcOrderController extends orderManagementImplBase {
    @Autowired
    OrderService orderService;

    @Override
    public void orderRecieve(Order.SaveOrder request, StreamObserver<Order.APIResponse> responseObserver)  {

        com.trp.order.ordermangmnt.model.Order order=new
                com.trp.order.ordermangmnt.model.Order
                (request.getTicker(),new Date(),request.getQuantity(),
                        request.getPrice(),request.getDirection());
        OrderStatus orderStatus=orderService.recieveOrder(order);
        Order.APIResponse.Builder response=Order.APIResponse.newBuilder().setResponseCode(orderStatus.getStatusCode()).setResponsemessage(orderStatus.getStatus());
        responseObserver.onNext(response.build());
        responseObserver.onCompleted();
    }

    @Override
    public void orderRetrieve(Order.GetOrder request, StreamObserver<Order.GetOrder> responseObserver) {

        com.trp.order.ordermangmnt.model.Order order=new com.trp.order.ordermangmnt.model.Order();
        order.setOrderId(request.getOrderId());
        com.trp.order.ordermangmnt.model.Order orderRespone =orderService.retrieveOrder(order.getOrderId());
        Date dateandTime=orderRespone.getOrderTime();

        Order.GetOrder.Builder response=Order.GetOrder.newBuilder().
                setOrderId(orderRespone.getOrderId()).setTicker(orderRespone.getTicker()).setOrderTime(orderRespone.getOrderTime().toString()).setQuantity(orderRespone.getQuantity()).setPrice(orderRespone.getPrice()).setDirection(orderRespone.getDirection());
        responseObserver.onNext(response.build());
        responseObserver.onCompleted();
    }
}
