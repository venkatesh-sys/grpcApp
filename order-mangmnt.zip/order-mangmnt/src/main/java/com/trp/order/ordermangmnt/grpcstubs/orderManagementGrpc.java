package com.trp.order.ordermangmnt.grpcstubs;

import static io.grpc.MethodDescriptor.generateFullMethodName;
import static io.grpc.stub.ClientCalls.asyncBidiStreamingCall;
import static io.grpc.stub.ClientCalls.asyncClientStreamingCall;
import static io.grpc.stub.ClientCalls.asyncServerStreamingCall;
import static io.grpc.stub.ClientCalls.asyncUnaryCall;
import static io.grpc.stub.ClientCalls.blockingServerStreamingCall;
import static io.grpc.stub.ClientCalls.blockingUnaryCall;
import static io.grpc.stub.ClientCalls.futureUnaryCall;
import static io.grpc.stub.ServerCalls.asyncBidiStreamingCall;
import static io.grpc.stub.ServerCalls.asyncClientStreamingCall;
import static io.grpc.stub.ServerCalls.asyncServerStreamingCall;
import static io.grpc.stub.ServerCalls.asyncUnaryCall;
import static io.grpc.stub.ServerCalls.asyncUnimplementedStreamingCall;
import static io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall;

/**
 */
@javax.annotation.Generated(
    value = "by gRPC proto compiler (version 1.28.1)",
    comments = "Source: order.proto")
public final class orderManagementGrpc {

  private orderManagementGrpc() {}

  public static final String SERVICE_NAME = "orderManagement";

  // Static method descriptors that strictly reflect the proto.
  private static volatile io.grpc.MethodDescriptor<com.trp.order.Order.SaveOrder,
      com.trp.order.Order.APIResponse> getOrderRecieveMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "orderRecieve",
      requestType = com.trp.order.Order.SaveOrder.class,
      responseType = com.trp.order.Order.APIResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.trp.order.Order.SaveOrder,
      com.trp.order.Order.APIResponse> getOrderRecieveMethod() {
    io.grpc.MethodDescriptor<com.trp.order.Order.SaveOrder, com.trp.order.Order.APIResponse> getOrderRecieveMethod;
    if ((getOrderRecieveMethod = orderManagementGrpc.getOrderRecieveMethod) == null) {
      synchronized (orderManagementGrpc.class) {
        if ((getOrderRecieveMethod = orderManagementGrpc.getOrderRecieveMethod) == null) {
          orderManagementGrpc.getOrderRecieveMethod = getOrderRecieveMethod =
              io.grpc.MethodDescriptor.<com.trp.order.Order.SaveOrder, com.trp.order.Order.APIResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "orderRecieve"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.trp.order.Order.SaveOrder.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.trp.order.Order.APIResponse.getDefaultInstance()))
              .setSchemaDescriptor(new orderManagementMethodDescriptorSupplier("orderRecieve"))
              .build();
        }
      }
    }
    return getOrderRecieveMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.trp.order.Order.GetOrder,
      com.trp.order.Order.GetOrder> getOrderRetrieveMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "orderRetrieve",
      requestType = com.trp.order.Order.GetOrder.class,
      responseType = com.trp.order.Order.GetOrder.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.trp.order.Order.GetOrder,
      com.trp.order.Order.GetOrder> getOrderRetrieveMethod() {
    io.grpc.MethodDescriptor<com.trp.order.Order.GetOrder, com.trp.order.Order.GetOrder> getOrderRetrieveMethod;
    if ((getOrderRetrieveMethod = orderManagementGrpc.getOrderRetrieveMethod) == null) {
      synchronized (orderManagementGrpc.class) {
        if ((getOrderRetrieveMethod = orderManagementGrpc.getOrderRetrieveMethod) == null) {
          orderManagementGrpc.getOrderRetrieveMethod = getOrderRetrieveMethod =
              io.grpc.MethodDescriptor.<com.trp.order.Order.GetOrder, com.trp.order.Order.GetOrder>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "orderRetrieve"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.trp.order.Order.GetOrder.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.trp.order.Order.GetOrder.getDefaultInstance()))
              .setSchemaDescriptor(new orderManagementMethodDescriptorSupplier("orderRetrieve"))
              .build();
        }
      }
    }
    return getOrderRetrieveMethod;
  }

  /**
   * Creates a new async stub that supports all call types for the service
   */
  public static orderManagementStub newStub(io.grpc.Channel channel) {
    io.grpc.stub.AbstractStub.StubFactory<orderManagementStub> factory =
      new io.grpc.stub.AbstractStub.StubFactory<orderManagementStub>() {
        @Override
        public orderManagementStub newStub(io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
          return new orderManagementStub(channel, callOptions);
        }
      };
    return orderManagementStub.newStub(factory, channel);
  }

  /**
   * Creates a new blocking-style stub that supports unary and streaming output calls on the service
   */
  public static orderManagementBlockingStub newBlockingStub(
      io.grpc.Channel channel) {
    io.grpc.stub.AbstractStub.StubFactory<orderManagementBlockingStub> factory =
      new io.grpc.stub.AbstractStub.StubFactory<orderManagementBlockingStub>() {
        @Override
        public orderManagementBlockingStub newStub(io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
          return new orderManagementBlockingStub(channel, callOptions);
        }
      };
    return orderManagementBlockingStub.newStub(factory, channel);
  }

  /**
   * Creates a new ListenableFuture-style stub that supports unary calls on the service
   */
  public static orderManagementFutureStub newFutureStub(
      io.grpc.Channel channel) {
    io.grpc.stub.AbstractStub.StubFactory<orderManagementFutureStub> factory =
      new io.grpc.stub.AbstractStub.StubFactory<orderManagementFutureStub>() {
        @Override
        public orderManagementFutureStub newStub(io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
          return new orderManagementFutureStub(channel, callOptions);
        }
      };
    return orderManagementFutureStub.newStub(factory, channel);
  }

  /**
   */
  public static abstract class orderManagementImplBase implements io.grpc.BindableService {

    /**
     */
    public void orderRecieve(com.trp.order.Order.SaveOrder request,
        io.grpc.stub.StreamObserver<com.trp.order.Order.APIResponse> responseObserver) {
      asyncUnimplementedUnaryCall(getOrderRecieveMethod(), responseObserver);
    }

    /**
     */
    public void orderRetrieve(com.trp.order.Order.GetOrder request,
        io.grpc.stub.StreamObserver<com.trp.order.Order.GetOrder> responseObserver) {
      asyncUnimplementedUnaryCall(getOrderRetrieveMethod(), responseObserver);
    }

    @Override public final io.grpc.ServerServiceDefinition bindService() {
      return io.grpc.ServerServiceDefinition.builder(getServiceDescriptor())
          .addMethod(
            getOrderRecieveMethod(),
            asyncUnaryCall(
              new MethodHandlers<
                com.trp.order.Order.SaveOrder,
                com.trp.order.Order.APIResponse>(
                  this, METHODID_ORDER_RECIEVE)))
          .addMethod(
            getOrderRetrieveMethod(),
            asyncUnaryCall(
              new MethodHandlers<
                com.trp.order.Order.GetOrder,
                com.trp.order.Order.GetOrder>(
                  this, METHODID_ORDER_RETRIEVE)))
          .build();
    }
  }

  /**
   */
  public static final class orderManagementStub extends io.grpc.stub.AbstractAsyncStub<orderManagementStub> {
    private orderManagementStub(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @Override
    protected orderManagementStub build(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      return new orderManagementStub(channel, callOptions);
    }

    /**
     */
    public void orderRecieve(com.trp.order.Order.SaveOrder request,
        io.grpc.stub.StreamObserver<com.trp.order.Order.APIResponse> responseObserver) {
      asyncUnaryCall(
          getChannel().newCall(getOrderRecieveMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void orderRetrieve(com.trp.order.Order.GetOrder request,
        io.grpc.stub.StreamObserver<com.trp.order.Order.GetOrder> responseObserver) {
      asyncUnaryCall(
          getChannel().newCall(getOrderRetrieveMethod(), getCallOptions()), request, responseObserver);
    }
  }

  /**
   */
  public static final class orderManagementBlockingStub extends io.grpc.stub.AbstractBlockingStub<orderManagementBlockingStub> {
    private orderManagementBlockingStub(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @Override
    protected orderManagementBlockingStub build(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      return new orderManagementBlockingStub(channel, callOptions);
    }

    /**
     */
    public com.trp.order.Order.APIResponse orderRecieve(com.trp.order.Order.SaveOrder request) {
      return blockingUnaryCall(
          getChannel(), getOrderRecieveMethod(), getCallOptions(), request);
    }

    /**
     */
    public com.trp.order.Order.GetOrder orderRetrieve(com.trp.order.Order.GetOrder request) {
      return blockingUnaryCall(
          getChannel(), getOrderRetrieveMethod(), getCallOptions(), request);
    }
  }

  /**
   */
  public static final class orderManagementFutureStub extends io.grpc.stub.AbstractFutureStub<orderManagementFutureStub> {
    private orderManagementFutureStub(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @Override
    protected orderManagementFutureStub build(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      return new orderManagementFutureStub(channel, callOptions);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<com.trp.order.Order.APIResponse> orderRecieve(
        com.trp.order.Order.SaveOrder request) {
      return futureUnaryCall(
          getChannel().newCall(getOrderRecieveMethod(), getCallOptions()), request);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<com.trp.order.Order.GetOrder> orderRetrieve(
        com.trp.order.Order.GetOrder request) {
      return futureUnaryCall(
          getChannel().newCall(getOrderRetrieveMethod(), getCallOptions()), request);
    }
  }

  private static final int METHODID_ORDER_RECIEVE = 0;
  private static final int METHODID_ORDER_RETRIEVE = 1;

  private static final class MethodHandlers<Req, Resp> implements
      io.grpc.stub.ServerCalls.UnaryMethod<Req, Resp>,
      io.grpc.stub.ServerCalls.ServerStreamingMethod<Req, Resp>,
      io.grpc.stub.ServerCalls.ClientStreamingMethod<Req, Resp>,
      io.grpc.stub.ServerCalls.BidiStreamingMethod<Req, Resp> {
    private final orderManagementImplBase serviceImpl;
    private final int methodId;

    MethodHandlers(orderManagementImplBase serviceImpl, int methodId) {
      this.serviceImpl = serviceImpl;
      this.methodId = methodId;
    }

    @Override
    @SuppressWarnings("unchecked")
    public void invoke(Req request, io.grpc.stub.StreamObserver<Resp> responseObserver) {
      switch (methodId) {
        case METHODID_ORDER_RECIEVE:
          serviceImpl.orderRecieve((com.trp.order.Order.SaveOrder) request,
              (io.grpc.stub.StreamObserver<com.trp.order.Order.APIResponse>) responseObserver);
          break;
        case METHODID_ORDER_RETRIEVE:
          serviceImpl.orderRetrieve((com.trp.order.Order.GetOrder) request,
              (io.grpc.stub.StreamObserver<com.trp.order.Order.GetOrder>) responseObserver);
          break;
        default:
          throw new AssertionError();
      }
    }

    @Override
    @SuppressWarnings("unchecked")
    public io.grpc.stub.StreamObserver<Req> invoke(
        io.grpc.stub.StreamObserver<Resp> responseObserver) {
      switch (methodId) {
        default:
          throw new AssertionError();
      }
    }
  }

  private static abstract class orderManagementBaseDescriptorSupplier
      implements io.grpc.protobuf.ProtoFileDescriptorSupplier, io.grpc.protobuf.ProtoServiceDescriptorSupplier {
    orderManagementBaseDescriptorSupplier() {}

    @Override
    public com.google.protobuf.Descriptors.FileDescriptor getFileDescriptor() {
      return com.trp.order.Order.getDescriptor();
    }

    @Override
    public com.google.protobuf.Descriptors.ServiceDescriptor getServiceDescriptor() {
      return getFileDescriptor().findServiceByName("orderManagement");
    }
  }

  private static final class orderManagementFileDescriptorSupplier
      extends orderManagementBaseDescriptorSupplier {
    orderManagementFileDescriptorSupplier() {}
  }

  private static final class orderManagementMethodDescriptorSupplier
      extends orderManagementBaseDescriptorSupplier
      implements io.grpc.protobuf.ProtoMethodDescriptorSupplier {
    private final String methodName;

    orderManagementMethodDescriptorSupplier(String methodName) {
      this.methodName = methodName;
    }

    @Override
    public com.google.protobuf.Descriptors.MethodDescriptor getMethodDescriptor() {
      return getServiceDescriptor().findMethodByName(methodName);
    }
  }

  private static volatile io.grpc.ServiceDescriptor serviceDescriptor;

  public static io.grpc.ServiceDescriptor getServiceDescriptor() {
    io.grpc.ServiceDescriptor result = serviceDescriptor;
    if (result == null) {
      synchronized (orderManagementGrpc.class) {
        result = serviceDescriptor;
        if (result == null) {
          serviceDescriptor = result = io.grpc.ServiceDescriptor.newBuilder(SERVICE_NAME)
              .setSchemaDescriptor(new orderManagementFileDescriptorSupplier())
              .addMethod(getOrderRecieveMethod())
              .addMethod(getOrderRetrieveMethod())
              .build();
        }
      }
    }
    return result;
  }
}
