package com.trp.order.ordermangmnt.controller;

import com.trp.order.ordermangmnt.ResourceNotFoundException;
import com.trp.order.ordermangmnt.model.Order;
import com.trp.order.ordermangmnt.repository.OrderRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1")
public class OrderController {
    @Autowired
private OrderRepository orderReposiory;
    @GetMapping("/order/{orderId}")
    public ResponseEntity<Order> getOrderById(@PathVariable(value = "orderId") Long orderId)
            throws ResourceNotFoundException {
        Order order = orderReposiory.findById(orderId)
                .orElseThrow(() -> new ResourceNotFoundException("order not found for this id :: " + orderId));
        return ResponseEntity.ok().body(order);
    }
    @PostMapping("/orders")
    public Order saveOrder(@RequestBody Order order) {

        return orderReposiory.save(order);
    }

}
