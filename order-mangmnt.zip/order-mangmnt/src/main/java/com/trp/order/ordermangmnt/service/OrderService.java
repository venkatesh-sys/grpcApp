package com.trp.order.ordermangmnt.service;
import com.trp.order.ordermangmnt.model.Order;
import com.trp.order.ordermangmnt.model.OrderStatus;
import com.trp.order.ordermangmnt.repository.OrderRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;
@Service
public class OrderService {
@Autowired
OrderRepository orderRepository;

public OrderStatus recieveOrder(Order order){

    order = orderRepository.save(order);
    OrderStatus orderStatus=new OrderStatus();
    if(null !=order && null != order.getOrderId()){
        orderStatus.setStatus("Order placed succesfully");
        orderStatus.setStatusCode(1);

    }
    else
    {
        orderStatus.setStatus("Order  not placed");
        orderStatus.setStatusCode(0);

    }

    return orderStatus;
}
public Order retrieveOrder(Long orderId){
    Optional<Order> order = orderRepository.findById(orderId);
    //Optional<Order> order= orderRepository.findById(orderId);
    return order.get();
}
}
