package com.trp.order.ordermangmnt.model;

import javax.persistence.*;
import java.util.Date;

@Entity
@Table(name = "order_table")
public class Order {
private Long OrderId;
private  String ticker;
private Date orderTime;
private int quantity;
private long price;
private String direction;

    public Order() {

    }


    @Column(name = "tricker", nullable = false)
    public String getTicker() {
        return ticker;
    }

    public void setTicker(String ticker) {
        this.ticker = ticker;
    }
    @Column(name = "order_time")
    @Temporal(TemporalType.TIMESTAMP)
    public Date getOrderTime() {
        return orderTime;
    }

    public void setOrderTime(Date orderTime) {
        this.orderTime = orderTime;
    }
    @Column(name = "quanity", nullable = false)
    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }
    @Column(name = "price", nullable = false)
    public long getPrice() {
        return price;
    }

    public void setPrice(Long price) {
        this.price = price;
    }
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    public Long getOrderId() {
        return OrderId;
    }

    public void setOrderId(long orderId) {
        OrderId = orderId;
    }
    @Column(name = "direction", nullable = false)
    public String getDirection() {
        return direction;
    }

    public void setDirection(String direction) {
        this.direction = direction;
    }

    public Order(String ticker, Date orderTime, int quantity, Long price, String direction) {
        this.ticker = ticker;
        this.orderTime = orderTime;
        this.quantity = quantity;
        this.price = price;
        this.direction = direction;
    }

}
