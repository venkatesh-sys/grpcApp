package com.trp.order.ordermangmnt;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.trp.order.ordermangmnt.controller.OrderController;
import com.trp.order.ordermangmnt.model.Order;
import com.trp.order.ordermangmnt.repository.OrderRepository;
import org.junit.Before;
import org.junit.internal.runners.JUnit4ClassRunner;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.event.annotation.BeforeTestMethod;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MockMvcBuilder;
import org.springframework.test.web.servlet.ResultActions;
import org.springframework.test.web.servlet.ResultMatcher;
import org.springframework.test.web.servlet.htmlunit.MockMvcWebClientBuilder;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.web.context.WebApplicationContext;

import java.util.Date;
import java.util.Optional;

import static org.mockito.Mockito.*;
import static org.mockito.Mockito.when;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.client.match.MockRestRequestMatchers.content;
import static org.springframework.test.web.client.match.MockRestRequestMatchers.jsonPath;
import static org.springframework.test.web.servlet.setup.MockMvcBuilders.standaloneSetup;
import static org.springframework.test.web.servlet.setup.MockMvcBuilders.webAppContextSetup;
import static org.hamcrest.Matchers.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;
import static org.springframework.test.web.client.match.MockRestRequestMatchers.content;
@RunWith(JUnit4ClassRunner.class)
@WebMvcTest(value = OrderController.class)

@AutoConfigureMockMvc
public class OrderConrollerTest {
    @InjectMocks
    OrderController mockController;
    @MockBean
    OrderRepository mockRepository;
    @Autowired
    private MockMvc mockMvc;
    private WebApplicationContext webApplicationContext;
    @Before
    public void init() {
        //MockitoAnnotations.initMocks(this);
        //this.mockMvc = webAppContextSetup(webApplicationContext).build();
        mockMvc = standaloneSetup(new OrderController()).build();
    }



    @Test
    public void testRetrieveOrder() throws Exception {
        Order order= new Order("ticker",new Date(),123,15090L,"S");
        order.setOrderId(1);
Long userId=1L;
      //when(mockController.saveOrder(order)).thenReturn(order);
        //whe(repository.findAllById(1)).thenReturn(order);
      when(mockRepository.findById(userId)).thenReturn(Optional.of(order));


       mockMvc.perform(get("/api/v1/order/" +userId))
                .andExpect(status().isOk())
               .andExpect(MockMvcResultMatchers.content().contentType(MediaType.APPLICATION_JSON))
                .andExpect(MockMvcResultMatchers.jsonPath("$.orderId").value(1l))
               .andExpect(MockMvcResultMatchers.jsonPath("$.orderTime", is(notNullValue())))
                .andExpect(MockMvcResultMatchers.jsonPath("$.quantity").value(123))
                .andExpect(MockMvcResultMatchers.jsonPath("$.price").value(15090L))
            .andExpect(MockMvcResultMatchers.jsonPath("$.direction").value("S"));

    }
   /* @Test
    @DisplayName("POST /api/v1/orders")
    public void testSaveOrder() throws Exception {
        Order postorder= new Order("ticker",new Date(),123,15090L,"S");
Order returnOrder=new Order();

        Long orderId=1L;
        returnOrder.setOrderId(orderId);

        when(mockRepository.save(postorder)).thenReturn(any());
        mockMvc.perform(post("/api/v1/orders")
                .contentType(MediaType.APPLICATION_JSON)
                .content(asJsonString(postorder)))
                .andExpect(status().isOk())
                .andExpect(MockMvcResultMatchers.content().contentType(MediaType.APPLICATION_JSON))
             //   .andExpect(MockMvcResultMatchers.jsonPath("$.orderId").value(1l))
                .andExpect(MockMvcResultMatchers.jsonPath("$.orderTime", is(notNullValue())))
                .andExpect(MockMvcResultMatchers.jsonPath("$.quantity").value(123))
                .andExpect(MockMvcResultMatchers.jsonPath("$.price").value(15090L))
                .andExpect(MockMvcResultMatchers.jsonPath("$.direction").value("S"));

    }*/
    static String asJsonString(final Object obj) {
        try {
            return new ObjectMapper().writeValueAsString(obj);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }


    }




